---
name: 为项目提BUG
about: 为该项目一个BUG
title: ''
labels: bug
assignees: ''

---

你好，请使用下面的模板创建 issue 以帮助我们更快的排查问题，不规范的 issue 会被关闭，感谢配合。

Browser version [浏览器类型和版本]
 

vue-h5-template version [vue-h5-template 版本]
 

Vue version [Vue  版本]
 

reappear link [重现链接]
 

One-line summary  [描述问题]


Other comments [其他信息]
