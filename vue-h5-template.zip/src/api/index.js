const api = {
  Login: '/user/login',
  UserInfo: '/user/userinfo',
  UserName: '/user/name'
}

export default api
