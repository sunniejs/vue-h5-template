// import qs from 'qs'
// axios
// import request from '@/utils/request'
// home homeApi

const homeApi = {
  registerForWalkingFestival: '/ebapi/public_api/register_for_walking_festival'
}

export default homeApi
