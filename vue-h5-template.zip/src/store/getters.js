const getters = {
  userName: state => state.app.userName
}
export default getters
