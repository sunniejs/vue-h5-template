// 正式
module.exports = {
  title: 'vue-h5-template',
  baseUrl: 'https://www.xxx.com/', // 正式项目地址
  baseApi: 'https://vall.xiangleba.com.cn', // 正式api请求地址
  APPID: 'xxx',
  APPSECRET: 'xxx',
  $cdn: 'https://www.sunniejs.cn/static'
}
