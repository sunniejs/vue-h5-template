module.exports = {
  title: 'vue-h5-template',
  baseUrl: 'https://test.xxx.com', // 测试项目地址
  baseApi: 'https://test.xxx.com/api', // 测试api请求地址
  APPID: 'xxx',
  APPSECRET: 'xxx',
  $cdn: 'https://www.sunniejs.cn/static'
}
